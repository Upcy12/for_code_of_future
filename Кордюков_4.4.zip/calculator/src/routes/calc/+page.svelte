<script>
    import {createEventDispatcher} from 'svelte';
    const dispatch =createEventDispatcher();

    let num1 =0;
    let num2 =0;
    let action = '+';
    let result = 0;

    function calculate(){
        switch(action){
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '/':
                result = num1 / num2;
                break;
            case '*':
                result = num1 * num2;
                break;
        }
        dispatch('calculation', {result});
    }

</script>
<main>
    <h1>Простой калькулятор</h1>
    
    <input type="number" bind:value={num1} placeholder="Ведите первое число"/><p></p>
    <select bind:value={action}>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="/">/</option>
        <option value="*">*</option>
    </select><p></p>
    <input type="number" bind:value={num2} placeholder="Введите второе число"/><p></p>
    <button on:click={calculate}>Посчитать</button>
    {#if result !=0}
        <p>Резульат: {result}</p>
    {/if}
</main>
<style>
    button{
        background-color: rgb(2, 206, 2);
    }

</style>